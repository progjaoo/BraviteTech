# Logos Bravite — opção 03 / Estrutura

Assinatura e símbolo preservam os contornos aprovados de `branding/03-estrutura.svg`. A versão horizontal teve apenas a prancheta recortada; a versão vertical reorganiza os mesmos elementos sem deformar suas proporções.

## Arquivos

Em `horizontal/`, `vertical/` e `simbolo/`:

- `principal`: verde floresta #132A21 e detalhe lima #B1E634; usar em fundo claro.
- `reversa`: branco e detalhe lima; usar em fundo verde floresta ou fundo escuro uniforme.
- `preta`: todas as formas em #000000; uso monocromático em fundo claro.
- `branca`: todas as formas em #FFFFFF; uso monocromático em fundo escuro.

Cada combinação inclui SVG vetorial, PNG transparente e PDF vetorial RGB. As versões brancas podem parecer vazias ao abrir sobre fundo branco. O fundo não faz parte desses arquivos; posicione-as sobre uma superfície escura.

PNG horizontal: 3000px de largura. PNG vertical: 2400px. Símbolo: 1600px. Os SVGs têm letras em curvas e não dependem de fontes ou arquivos externos.

## Uso

Priorize SVG no site e em peças editáveis; PNG para plataformas que não aceitam vetores; PDF para encaminhamento a fornecedores. Os PDFs estão em RGB, sem perfil CMYK, sangria ou marcas de corte. Confirme o processo de impressão com a gráfica antes de produzir.

Deixe ao redor da assinatura pelo menos 24 unidades livres no desenho original. Essa reserva fica fora da prancheta recortada. No uso vertical, mantenha a mesma proporção de respiro.

Referência digital sugerida: assinatura horizontal a partir de 180px de largura; vertical a partir de 160px; símbolo isolado a partir de 24px. Para abas de navegador, utilize os favicons específicos em `../04-web/icones/`, disponíveis em 16/32/48px.

Não esticar, inclinar, alterar os espaços internos, trocar cores, acrescentar contornos ou colocar o detalhe lima sobre fundo claro fora da composição original. A marca em lima puro não é uma variante fornecida.
